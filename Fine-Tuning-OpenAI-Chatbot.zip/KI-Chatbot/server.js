import express from 'express';
import bodyParser from 'body-parser';
import fetch from 'node-fetch';
import dotenv from 'dotenv';
import fs from 'fs';
import path from 'path';

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

app.use(bodyParser.json());
app.use(express.static('public'));

// Lire le fichier KI.txt
const kiFilePath = path.resolve('KI.txt');
let kiContent = '';

fs.readFile(kiFilePath, 'utf8', (err, data) => {
    if (err) {
        console.error('Erreur de lecture du fichier KI.txt:', err);
    } else {
        kiContent = data;
    }
});

app.post('/api/chat', async (req, res) => {
    const userMessage = req.body.message;
    const apiKey = process.env.OPENAI_API_KEY;

    const data = {
        model: '', // Utilisez l'ID du modèle fine-tuné
        prompt: `${kiContent}\n\nQ: ${userMessage}\nA:`,
        max_tokens: 150,
        temperature: 0.7
    };

    try {
        const response = await fetch('https://api.openai.com/v1/completions', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${apiKey}`
            },
            body: JSON.stringify(data)
        });

        const result = await response.json();
        if (result.error) {
            console.error('Erreur de génération de réponse OpenAI:', result.error);
            throw new Error(result.error.message);
        }
        res.json({ response: result.choices[0].text.trim() });
    } catch (error) {
        console.error('Erreur lors de la génération de la réponse:', error);
        res.status(500).json({ error: 'An error occurred' });
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
