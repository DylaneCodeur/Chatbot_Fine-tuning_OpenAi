# Contribuer à KI-Chatbotlebon

Merci de vouloir contribuer à KI-Chatbotlebon ! Nous apprécions votre aide et vos contributions. Pour assurer un processus de collaboration harmonieux, veuillez suivre les directives ci-dessous.

## Comment Contribuer

### Rapporter des Bugs

Si vous trouvez un bug, veuillez ouvrir une *issue* sur GitHub. Incluez autant de détails que possible pour nous aider à reproduire et résoudre le problème.

### Proposer des Améliorations

Si vous avez une idée pour améliorer le projet, ouvrez une *issue* avec une description claire de l'amélioration que vous proposez.

### Soumettre des Pull Requests

1. **Fork** le repository.
2. **Clone** votre fork :
    ```sh
    git clone https://github.com/votre-utilisateur/KI-Chatbotlebon.git
    ```
3. **Créez** une branche pour votre modification :
    ```sh
    git checkout -b feature-nouvelle-fonctionnalite
    ```
4. **Implémentez** vos changements.
5. **Commitez** vos modifications :
    ```sh
    git commit -m "Ajout d'une nouvelle fonctionnalité"
    ```
6. **Poussez** à la branche :
    ```sh
    git push origin feature-nouvelle-fonctionnalite
    ```
7. Ouvrez une *pull request* sur GitHub.

## Code de Conduite

Veuillez vous assurer que vos contributions respectent notre code de conduite pour maintenir un environnement collaboratif et respectueux.

## Licence

En contribuant à ce projet, vous acceptez que vos contributions soient sous la licence MIT.
